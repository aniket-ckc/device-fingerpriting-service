from fastapi import APIRouter

from .fingerprint import router as fingerprint_router
from .device import router as device_router
from .health import router as health_router


router = APIRouter(prefix="/api/v1")

router.include_router(fingerprint_router)
router.include_router(device_router)
router.include_router(health_router)
