from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from ...infrastructure.database.session import get_session
from ...infrastructure.schemas.device import DeviceResponse, DeviceHistoryResponse
from ...infrastructure.database.repositories.device_repository_impl import DeviceRepositoryImpl
from ...application.device_service import DeviceService


router = APIRouter(prefix="/devices", tags=["devices"])


@router.get("/{device_id}", response_model=DeviceResponse)
async def get_device(
    device_id: str,
    session: AsyncSession = Depends(get_session),
):
    """Get device information"""
    device_repo = DeviceRepositoryImpl(session)
    service = DeviceService(device_repo)
    
    device = await service.get_device(device_id)
    if device is None:
        raise HTTPException(status_code=404, detail="Device not found")
    
    return device


@router.get("/{device_id}/history", response_model=DeviceHistoryResponse)
async def get_device_history(
    device_id: str,
    session: AsyncSession = Depends(get_session),
):
    """Get device observation history"""
    device_repo = DeviceRepositoryImpl(session)
    service = DeviceService(device_repo)
    
    device = await service.get_device_history(device_id)
    if device is None:
        raise HTTPException(status_code=404, detail="Device not found")
    
    return DeviceHistoryResponse(
        device_id=device.id,
        first_seen=device.first_seen,
        last_seen=device.last_seen,
        observations=device.observation_count,
    )
