from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from ...infrastructure.database.session import get_session
from ...infrastructure.schemas.fingerprint import FingerprintRequest, FingerprintResponse
from ...infrastructure.database.repositories.fingerprint_repository_impl import FingerprintRepositoryImpl
from ...infrastructure.database.repositories.device_repository_impl import DeviceRepositoryImpl
from ...application.fingerprint_service import FingerprintService


router = APIRouter(prefix="/fingerprints", tags=["fingerprints"])


@router.post("", response_model=FingerprintResponse)
async def create_fingerprint(
    request: FingerprintRequest,
    session: AsyncSession = Depends(get_session),
):
    """Create or identify a fingerprint"""
    fingerprint_repo = FingerprintRepositoryImpl(session)
    device_repo = DeviceRepositoryImpl(session)
    service = FingerprintService(fingerprint_repo, device_repo)
    
    fingerprint_id, device_id, confidence, is_new = await service.process_fingerprint(
        request.signals
    )
    
    return FingerprintResponse(
        fingerprint_id=fingerprint_id,
        device_id=device_id,
        confidence=confidence,
        is_new=is_new,
    )


@router.post("/compare")
async def compare_fingerprints(
    fingerprint_a: str,
    fingerprint_b: str,
    session: AsyncSession = Depends(get_session),
):
    """Compare two fingerprints"""
    from ...application.matching_service import MatchingService
    
    fingerprint_repo = FingerprintRepositoryImpl(session)
    service = MatchingService(fingerprint_repo)
    
    similarity_score, matched = await service.compare_fingerprints(
        fingerprint_a, fingerprint_b
    )
    
    return {
        "similarity_score": similarity_score,
        "matched": matched,
    }
