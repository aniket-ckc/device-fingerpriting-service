from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .api.v1.router import router
from .config.logging import setup_logging
from .config.settings import settings


def create_app() -> FastAPI:
    """Create and configure FastAPI application"""
    setup_logging()
    
    app = FastAPI(
        title="Device Fingerprinting Service",
        description="Microservice for device identification and fingerprinting",
        version="0.1.0",
    )
    
    # CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    @app.get("/", tags=["Health"])
    async def health_check():
        return {"status": "healthy"}
    
    # Routes
    app.include_router(router)
    
    return app


app = create_app()


if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.environment == "development",
    )
