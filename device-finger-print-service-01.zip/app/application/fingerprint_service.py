import uuid
from typing import Optional, Tuple
from datetime import datetime

from ..domain.entities.fingerprint import Fingerprint
from ..domain.entities.device import Device
from ..domain.entities.observation import Observation
from ..domain.repositories.fingerprint_repository import FingerprintRepository
from ..domain.repositories.device_repository import DeviceRepository
from ..domain.services.fingerprint_generator import FingerprintGenerator
from ..domain.services.fingerprint_matcher import FingerprintMatcher
from ..infrastructure.hashing.sha256 import SHA256Hasher


class FingerprintService:
    """Application service for fingerprint processing"""
    
    def __init__(
        self,
        fingerprint_repo: FingerprintRepository,
        device_repo: DeviceRepository,
    ):
        self.fingerprint_repo = fingerprint_repo
        self.device_repo = device_repo
    
    async def process_fingerprint(
        self,
        signals: dict,
    ) -> Tuple[str, str, float, bool]:
        """
        Process a fingerprint and return:
        - fingerprint_id
        - device_id
        - confidence score
        - is_new_device
        """
        # Generate fingerprint from signals
        fingerprint = FingerprintGenerator.generate(signals)
        fingerprint.id = str(uuid.uuid4())
        
        # Calculate hash
        fingerprint_dict = {
            "user_agent": fingerprint.user_agent,
            "platform": fingerprint.platform,
            "timezone": fingerprint.timezone,
            "webgl": fingerprint.webgl,
            "canvas": fingerprint.canvas,
        }
        fingerprint.hash = SHA256Hasher.hash_fingerprint(fingerprint_dict)
        
        # Save fingerprint
        saved_fingerprint = await self.fingerprint_repo.save(fingerprint)
        
        # Try to find matching fingerprint
        existing_fingerprint = await self.fingerprint_repo.get_by_hash(
            saved_fingerprint.hash
        )
        
        is_new_device = existing_fingerprint is None
        device_id = str(uuid.uuid4()) if is_new_device else existing_fingerprint.id
        confidence = 1.0 if is_new_device else 0.95
        
        # Get or create device
        device = await self.device_repo.get_by_id(device_id)
        if device is None:
            device = Device(id=device_id)
            await self.device_repo.save(device)
        else:
            device.last_seen = datetime.utcnow()
            device.observation_count += 1
            await self.device_repo.update(device)
        
        return saved_fingerprint.id, device_id, confidence, is_new_device
