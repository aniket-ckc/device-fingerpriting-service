from typing import Optional
from ..domain.entities.device import Device
from ..domain.repositories.device_repository import DeviceRepository


class DeviceService:
    """Application service for device operations"""
    
    def __init__(self, device_repo: DeviceRepository):
        self.device_repo = device_repo
    
    async def get_device(self, device_id: str) -> Optional[Device]:
        """Retrieve device by ID"""
        return await self.device_repo.get_by_id(device_id)
    
    async def get_device_history(self, device_id: str) -> Optional[Device]:
        """Get device observation history"""
        return await self.device_repo.get_by_id(device_id)
