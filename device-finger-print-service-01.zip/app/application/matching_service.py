from typing import Optional

from ..domain.entities.fingerprint import Fingerprint
from ..domain.repositories.fingerprint_repository import FingerprintRepository
from ..domain.services.fingerprint_matcher import FingerprintMatcher
from ..domain.value_objects.similarity_score import SimilarityScore


class MatchingService:
    """Application service for fingerprint matching"""
    
    def __init__(self, fingerprint_repo: FingerprintRepository):
        self.fingerprint_repo = fingerprint_repo
    
    async def compare_fingerprints(
        self,
        fingerprint_a_id: str,
        fingerprint_b_id: str,
    ) -> tuple[float, bool]:
        """
        Compare two fingerprints and return:
        - similarity_score
        - matched (boolean)
        """
        fingerprint_a = await self.fingerprint_repo.get_by_id(fingerprint_a_id)
        fingerprint_b = await self.fingerprint_repo.get_by_id(fingerprint_b_id)
        
        if fingerprint_a is None or fingerprint_b is None:
            return 0.0, False
        
        similarity = FingerprintMatcher.match(fingerprint_a, fingerprint_b)
        matched = similarity.is_match(threshold=0.85)
        
        return float(similarity.value), matched
