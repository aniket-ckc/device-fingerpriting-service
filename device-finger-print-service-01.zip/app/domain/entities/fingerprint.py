from datetime import datetime
from typing import Optional
from dataclasses import dataclass, field


@dataclass
class Fingerprint:
    """Raw fingerprint entity representing collected browser characteristics"""
    
    user_agent: str
    platform: str
    language: str
    timezone: str
    screen_width: int
    screen_height: int
    pixel_ratio: float
    cpu_cores: int
    memory_gb: int
    webgl: Optional[str] = None
    canvas: Optional[str] = None
    fonts: Optional[list[str]] = field(default_factory=list)
    
    id: Optional[str] = None
    hash: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    def __hash__(self) -> int:
        return hash((self.user_agent, self.platform, self.timezone))
