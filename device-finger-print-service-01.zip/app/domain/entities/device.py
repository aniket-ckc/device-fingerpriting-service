from datetime import datetime
from typing import Optional
from dataclasses import dataclass, field


@dataclass
class Device:
    """Device identity entity - represents a unique device"""
    
    id: str
    first_seen: datetime = field(default_factory=datetime.utcnow)
    last_seen: datetime = field(default_factory=datetime.utcnow)
    observation_count: int = 0
    risk_score: float = 0.0
    is_flagged: bool = False
    metadata: Optional[dict] = None
