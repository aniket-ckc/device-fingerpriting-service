from datetime import datetime
from typing import Optional
from dataclasses import dataclass, field


@dataclass
class Observation:
    """Observation entity - records a fingerprint collection event"""
    
    fingerprint_id: str
    device_id: str
    ip_address: Optional[str] = None
    user_id: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.utcnow)
    session_id: Optional[str] = None
    risk_indicators: Optional[dict] = None
    
    id: Optional[str] = None
