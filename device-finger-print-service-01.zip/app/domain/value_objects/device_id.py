from dataclasses import dataclass


@dataclass(frozen=True)
class DeviceId:
    """Value object for device identity"""
    
    value: str
    
    def __str__(self) -> str:
        return self.value
