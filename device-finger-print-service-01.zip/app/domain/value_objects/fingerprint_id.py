from dataclasses import dataclass


@dataclass(frozen=True)
class FingerprintId:
    """Value object for fingerprint identity"""
    
    value: str
    
    def __str__(self) -> str:
        return self.value
