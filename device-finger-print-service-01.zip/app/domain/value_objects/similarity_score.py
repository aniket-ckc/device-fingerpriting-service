from dataclasses import dataclass


@dataclass(frozen=True)
class SimilarityScore:
    """Value object for similarity score between fingerprints"""
    
    value: float
    
    def __post_init__(self) -> None:
        if not 0.0 <= self.value <= 1.0:
            raise ValueError("Similarity score must be between 0.0 and 1.0")
    
    def is_match(self, threshold: float = 0.85) -> bool:
        return self.value >= threshold
    
    def __str__(self) -> str:
        return f"{self.value:.2%}"
