from abc import ABC, abstractmethod
from typing import Optional, List
from ..entities.device import Device


class DeviceRepository(ABC):
    """Abstract repository for device persistence"""
    
    @abstractmethod
    async def save(self, device: Device) -> Device:
        """Save device to storage"""
        pass
    
    @abstractmethod
    async def get_by_id(self, device_id: str) -> Optional[Device]:
        """Retrieve device by ID"""
        pass
    
    @abstractmethod
    async def get_all(self, limit: int = 100, offset: int = 0) -> List[Device]:
        """Retrieve all devices with pagination"""
        pass
    
    @abstractmethod
    async def update(self, device: Device) -> Device:
        """Update existing device"""
        pass
