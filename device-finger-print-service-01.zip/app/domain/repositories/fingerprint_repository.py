from abc import ABC, abstractmethod
from typing import Optional, List
from ..entities.fingerprint import Fingerprint


class FingerprintRepository(ABC):
    """Abstract repository for fingerprint persistence"""
    
    @abstractmethod
    async def save(self, fingerprint: Fingerprint) -> Fingerprint:
        """Save fingerprint to storage"""
        pass
    
    @abstractmethod
    async def get_by_id(self, fingerprint_id: str) -> Optional[Fingerprint]:
        """Retrieve fingerprint by ID"""
        pass
    
    @abstractmethod
    async def get_by_hash(self, hash_value: str) -> Optional[Fingerprint]:
        """Retrieve fingerprint by hash"""
        pass
    
    @abstractmethod
    async def get_all(self, limit: int = 100, offset: int = 0) -> List[Fingerprint]:
        """Retrieve all fingerprints with pagination"""
        pass
