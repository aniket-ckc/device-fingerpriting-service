from typing import Dict, Any
from ..entities.fingerprint import Fingerprint


class FingerprintGenerator:
    """Service for generating fingerprints from signals"""
    
    @staticmethod
    def generate(signals: Dict[str, Any]) -> Fingerprint:
        """Create a fingerprint entity from collected signals"""
        return Fingerprint(
            user_agent=signals.get("userAgent", ""),
            platform=signals.get("platform", ""),
            language=signals.get("language", ""),
            timezone=signals.get("timezone", ""),
            screen_width=signals.get("screen", {}).get("width", 0),
            screen_height=signals.get("screen", {}).get("height", 0),
            pixel_ratio=signals.get("screen", {}).get("pixelRatio", 1.0),
            cpu_cores=signals.get("hardware", {}).get("cpuCores", 0),
            memory_gb=signals.get("hardware", {}).get("memory", 0),
            webgl=signals.get("webgl"),
            canvas=signals.get("canvas"),
            fonts=signals.get("fonts", []),
        )
