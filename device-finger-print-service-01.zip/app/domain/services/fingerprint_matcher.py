from typing import Dict
from ..entities.fingerprint import Fingerprint
from ..value_objects.similarity_score import SimilarityScore


class FingerprintMatcher:
    """Service for comparing fingerprints and calculating similarity"""
    
    WEIGHTS = {
        "webgl": 0.25,
        "platform": 0.15,
        "browser": 0.15,
        "timezone": 0.10,
        "screen": 0.10,
        "language": 0.05,
        "cpu_cores": 0.05,
        "canvas": 0.10,
        "fonts": 0.05,
    }
    
    @staticmethod
    def match(fingerprint_a: Fingerprint, fingerprint_b: Fingerprint) -> SimilarityScore:
        """Calculate weighted similarity score between two fingerprints"""
        score = 0.0
        
        # WebGL comparison (highest weight)
        if fingerprint_a.webgl and fingerprint_b.webgl:
            score += (fingerprint_a.webgl == fingerprint_b.webgl) * FingerprintMatcher.WEIGHTS["webgl"]
        
        # Platform comparison
        if fingerprint_a.platform == fingerprint_b.platform:
            score += FingerprintMatcher.WEIGHTS["platform"]
        
        # User agent comparison
        if fingerprint_a.user_agent == fingerprint_b.user_agent:
            score += FingerprintMatcher.WEIGHTS["browser"]
        
        # Timezone comparison
        if fingerprint_a.timezone == fingerprint_b.timezone:
            score += FingerprintMatcher.WEIGHTS["timezone"]
        
        # Screen comparison
        if (fingerprint_a.screen_width == fingerprint_b.screen_width and 
            fingerprint_a.screen_height == fingerprint_b.screen_height):
            score += FingerprintMatcher.WEIGHTS["screen"]
        
        # Language comparison
        if fingerprint_a.language == fingerprint_b.language:
            score += FingerprintMatcher.WEIGHTS["language"]
        
        # CPU cores comparison
        if fingerprint_a.cpu_cores == fingerprint_b.cpu_cores:
            score += FingerprintMatcher.WEIGHTS["cpu_cores"]
        
        # Canvas comparison
        if fingerprint_a.canvas and fingerprint_b.canvas:
            score += (fingerprint_a.canvas == fingerprint_b.canvas) * FingerprintMatcher.WEIGHTS["canvas"]
        
        # Fonts comparison
        if fingerprint_a.fonts and fingerprint_b.fonts:
            matching_fonts = set(fingerprint_a.fonts) & set(fingerprint_b.fonts)
            font_similarity = len(matching_fonts) / max(len(fingerprint_a.fonts), len(fingerprint_b.fonts))
            score += font_similarity * FingerprintMatcher.WEIGHTS["fonts"]
        
        return SimilarityScore(min(score, 1.0))
