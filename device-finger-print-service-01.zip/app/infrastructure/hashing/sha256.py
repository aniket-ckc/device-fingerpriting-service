import hashlib
from typing import Dict, Any


class SHA256Hasher:
    """SHA256 hashing utility for fingerprints"""
    
    @staticmethod
    def hash_fingerprint(fingerprint_data: Dict[str, Any]) -> str:
        """Generate SHA256 hash from fingerprint data"""
        # Create a deterministic string representation
        sorted_items = sorted(fingerprint_data.items())
        content = str(sorted_items)
        return hashlib.sha256(content.encode()).hexdigest()
