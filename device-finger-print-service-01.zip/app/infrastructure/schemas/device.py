from pydantic import BaseModel
from datetime import datetime
from typing import Optional


class DeviceResponse(BaseModel):
    """Schema for device response"""
    id: str
    first_seen: datetime
    last_seen: datetime
    observation_count: int
    risk_score: float
    is_flagged: bool
    metadata: Optional[dict] = None
    
    class Config:
        from_attributes = True


class DeviceHistoryResponse(BaseModel):
    """Schema for device history response"""
    device_id: str
    first_seen: datetime
    last_seen: datetime
    observations: int
    
    class Config:
        from_attributes = True
