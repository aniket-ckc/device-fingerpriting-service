from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime


class FingerprintRequest(BaseModel):
    """Schema for fingerprint creation request"""
    signals: dict


class FingerprintResponse(BaseModel):
    """Schema for fingerprint response"""
    fingerprint_id: str
    device_id: str
    confidence: float
    is_new: bool
    similarity_score: Optional[float] = None
    
    class Config:
        from_attributes = True
