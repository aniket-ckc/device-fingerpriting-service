from sqlalchemy import Column, String, Integer, Float, DateTime, Text, JSON
from sqlalchemy.sql import func
from datetime import datetime
from .base import Base


class FingerprintModel(Base):
    __tablename__ = "fingerprints"
    
    id = Column(String(64), primary_key=True, index=True)
    hash = Column(String(64), unique=True, index=True)
    user_agent = Column(String(512))
    platform = Column(String(128))
    language = Column(String(32))
    timezone = Column(String(64))
    screen_width = Column(Integer)
    screen_height = Column(Integer)
    pixel_ratio = Column(Float)
    cpu_cores = Column(Integer)
    memory_gb = Column(Integer)
    webgl = Column(String(256), nullable=True)
    canvas = Column(String(256), nullable=True)
    fonts = Column(JSON, nullable=True)
    created_at = Column(DateTime(timezone=False), server_default=func.now())
