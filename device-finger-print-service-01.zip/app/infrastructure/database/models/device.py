from sqlalchemy import Column, String, DateTime, Integer, Float, Boolean, JSON
from sqlalchemy.sql import func
from datetime import datetime
from .base import Base


class DeviceModel(Base):
    __tablename__ = "devices"
    
    id = Column(String(64), primary_key=True, index=True)
    first_seen = Column(DateTime(timezone=False), server_default=func.now())
    last_seen = Column(DateTime(timezone=False), server_default=func.now(), onupdate=func.now())
    observation_count = Column(Integer, default=0)
    risk_score = Column(Float, default=0.0)
    is_flagged = Column(Boolean, default=False)
    metadata = Column(JSON, nullable=True)
