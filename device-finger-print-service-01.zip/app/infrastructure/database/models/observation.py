from sqlalchemy import Column, String, DateTime, JSON, ForeignKey
from sqlalchemy.sql import func
from datetime import datetime
from .base import Base


class ObservationModel(Base):
    __tablename__ = "observations"
    
    id = Column(String(64), primary_key=True, index=True)
    fingerprint_id = Column(String(64), ForeignKey("fingerprints.id"))
    device_id = Column(String(64), ForeignKey("devices.id"))
    ip_address = Column(String(45), nullable=True)
    user_id = Column(String(256), nullable=True)
    timestamp = Column(DateTime(timezone=False), server_default=func.now())
    session_id = Column(String(256), nullable=True, index=True)
    risk_indicators = Column(JSON, nullable=True)
