from typing import Optional, List
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ....domain.repositories.device_repository import DeviceRepository
from ....domain.entities.device import Device
from ..models.device import DeviceModel


class DeviceRepositoryImpl(DeviceRepository):
    """SQLAlchemy implementation of device repository"""
    
    def __init__(self, session: AsyncSession):
        self.session = session
    
    async def save(self, device: Device) -> Device:
        model = DeviceModel(
            id=device.id,
            first_seen=device.first_seen,
            last_seen=device.last_seen,
            observation_count=device.observation_count,
            risk_score=device.risk_score,
            is_flagged=device.is_flagged,
            metadata=device.metadata,
        )
        self.session.add(model)
        await self.session.commit()
        await self.session.refresh(model)
        return self._model_to_entity(model)
    
    async def get_by_id(self, device_id: str) -> Optional[Device]:
        stmt = select(DeviceModel).where(DeviceModel.id == device_id)
        result = await self.session.execute(stmt)
        model = result.scalars().first()
        return self._model_to_entity(model) if model else None
    
    async def get_all(self, limit: int = 100, offset: int = 0) -> List[Device]:
        stmt = select(DeviceModel).limit(limit).offset(offset)
        result = await self.session.execute(stmt)
        models = result.scalars().all()
        return [self._model_to_entity(model) for model in models]
    
    async def update(self, device: Device) -> Device:
        stmt = select(DeviceModel).where(DeviceModel.id == device.id)
        result = await self.session.execute(stmt)
        model = result.scalars().first()
        
        if model:
            model.last_seen = device.last_seen
            model.observation_count = device.observation_count
            model.risk_score = device.risk_score
            model.is_flagged = device.is_flagged
            model.metadata = device.metadata
            await self.session.commit()
            await self.session.refresh(model)
        
        return self._model_to_entity(model) if model else device
    
    @staticmethod
    def _model_to_entity(model: DeviceModel) -> Device:
        return Device(
            id=model.id,
            first_seen=model.first_seen,
            last_seen=model.last_seen,
            observation_count=model.observation_count,
            risk_score=model.risk_score,
            is_flagged=model.is_flagged,
            metadata=model.metadata,
        )
