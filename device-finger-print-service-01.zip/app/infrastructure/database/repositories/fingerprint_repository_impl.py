from typing import Optional, List
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Session

from ....domain.repositories.fingerprint_repository import FingerprintRepository
from ....domain.entities.fingerprint import Fingerprint
from ..models.fingerprint import FingerprintModel


class FingerprintRepositoryImpl(FingerprintRepository):
    """SQLAlchemy implementation of fingerprint repository"""
    
    def __init__(self, session: AsyncSession):
        self.session = session
    
    async def save(self, fingerprint: Fingerprint) -> Fingerprint:
        model = FingerprintModel(
            id=fingerprint.id,
            hash=fingerprint.hash,
            user_agent=fingerprint.user_agent,
            platform=fingerprint.platform,
            language=fingerprint.language,
            timezone=fingerprint.timezone,
            screen_width=fingerprint.screen_width,
            screen_height=fingerprint.screen_height,
            pixel_ratio=fingerprint.pixel_ratio,
            cpu_cores=fingerprint.cpu_cores,
            memory_gb=fingerprint.memory_gb,
            webgl=fingerprint.webgl,
            canvas=fingerprint.canvas,
            fonts=fingerprint.fonts,
        )
        self.session.add(model)
        await self.session.commit()
        await self.session.refresh(model)
        return self._model_to_entity(model)
    
    async def get_by_id(self, fingerprint_id: str) -> Optional[Fingerprint]:
        stmt = select(FingerprintModel).where(FingerprintModel.id == fingerprint_id)
        result = await self.session.execute(stmt)
        model = result.scalars().first()
        return self._model_to_entity(model) if model else None
    
    async def get_by_hash(self, hash_value: str) -> Optional[Fingerprint]:
        stmt = select(FingerprintModel).where(FingerprintModel.hash == hash_value)
        result = await self.session.execute(stmt)
        model = result.scalars().first()
        return self._model_to_entity(model) if model else None
    
    async def get_all(self, limit: int = 100, offset: int = 0) -> List[Fingerprint]:
        stmt = select(FingerprintModel).limit(limit).offset(offset)
        result = await self.session.execute(stmt)
        models = result.scalars().all()
        return [self._model_to_entity(model) for model in models]
    
    @staticmethod
    def _model_to_entity(model: FingerprintModel) -> Fingerprint:
        return Fingerprint(
            id=model.id,
            hash=model.hash,
            user_agent=model.user_agent,
            platform=model.platform,
            language=model.language,
            timezone=model.timezone,
            screen_width=model.screen_width,
            screen_height=model.screen_height,
            pixel_ratio=model.pixel_ratio,
            cpu_cores=model.cpu_cores,
            memory_gb=model.memory_gb,
            webgl=model.webgl,
            canvas=model.canvas,
            fonts=model.fonts,
            created_at=model.created_at,
        )
