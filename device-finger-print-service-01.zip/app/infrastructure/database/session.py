from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from ...config.settings import settings


# Map sqlite to aiosqlite
db_url = settings.db_url
if db_url.startswith("sqlite"):
    db_url = db_url.replace("sqlite", "sqlite+aiosqlite")

engine = create_async_engine(db_url, echo=False, future=True)

async_session = sessionmaker(
    engine, class_=AsyncSession, expire_on_commit=False, autoflush=False
)


async def get_session() -> AsyncSession:
    """Dependency for getting database session"""
    async with async_session() as session:
        yield session
