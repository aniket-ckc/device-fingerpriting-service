from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    database_url: str = "sqlite:///./fingerprint.db"
    database_url_prod: str = "postgresql://user:password@localhost/fingerprint"
    environment: str = "development"
    log_level: str = "INFO"
    
    class Config:
        env_file = ".env"
        case_sensitive = False
    
    @property
    def db_url(self) -> str:
        if self.environment == "production":
            return self.database_url_prod
        return self.database_url


settings = Settings()
